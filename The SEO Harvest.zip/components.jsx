// Components for The SEO Harvest

const { useState, useEffect, useRef } = React;

// ───────── Logo ─────────
function LogoMark({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <path d="M16 3 L16 29" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M16 8 Q10 10 8 6 Q10 13 16 12" fill="currentColor" />
      <path d="M16 8 Q22 10 24 6 Q22 13 16 12" fill="currentColor" opacity="0.7" />
      <path d="M16 14 Q9 16 7 11 Q9 19 16 18" fill="currentColor" />
      <path d="M16 14 Q23 16 25 11 Q23 19 16 18" fill="currentColor" opacity="0.7" />
      <path d="M16 20 Q10 22 8 17 Q10 25 16 24" fill="currentColor" />
      <path d="M16 20 Q22 22 24 17 Q22 25 16 24" fill="currentColor" opacity="0.7" />
    </svg>
  );
}

// ───────── Top bar ─────────
function TopBar({ onCTA }) {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <a className="logo" href="#top">
          <span className="logo-mark" style={{ color: "var(--gold-deep)" }}><LogoMark /></span>
          The SEO Harvest
        </a>
        <nav className="nav-links">
          <a href="#curriculum">Curriculum</a>
          <a href="#results">Results</a>
          <a href="#blog">Field Notes</a>
          <a href="#pricing">Pricing</a>
        </nav>
        <div className="topbar-cta">
          <button className="btn btn-ghost" onClick={() => onCTA("preview")}>Free lesson</button>
          <button className="btn btn-primary" onClick={() => onCTA("buy")}>Enroll</button>
        </div>
      </div>
    </header>
  );
}

// ───────── Urgency strip ─────────
function UrgencyStrip() {
  const items = [
    "Cohort 12 opens July 8",
    "Early-bird $200 off ends Sunday",
    "4,200+ operators trained",
    "60-day money-back guarantee",
    "New for 2026: AI-content module",
  ];
  return (
    <div className="urgency">
      <div className="urgency-track">
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i}>★ <strong>{t}</strong></span>
        ))}
      </div>
    </div>
  );
}

// ───────── Hero illustration ─────────
function HeroChart() {
  // Stylized rank progression chart
  const points = [
    { x: 0, y: 78 }, { x: 8, y: 82 }, { x: 16, y: 70 },
    { x: 24, y: 65 }, { x: 32, y: 56 }, { x: 40, y: 48 },
    { x: 48, y: 36 }, { x: 56, y: 28 }, { x: 64, y: 20 },
    { x: 72, y: 14 }, { x: 80, y: 10 }, { x: 88, y: 8 }, { x: 96, y: 6 },
  ];
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
  const area = `${path} L 96 100 L 0 100 Z`;
  return (
    <svg viewBox="0 0 100 100" preserveAspectRatio="none">
      <defs>
        <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--gold)" stopOpacity="0.4" />
          <stop offset="100%" stopColor="var(--gold)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#grad)" />
      <path d={path} stroke="var(--ink)" strokeWidth="0.8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {points.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r={i === points.length - 1 ? "1.4" : "0.6"} fill={i === points.length - 1 ? "var(--gold-deep)" : "var(--ink)"} />
      ))}
    </svg>
  );
}

function HeroArt() {
  return (
    <div className="hero-art" aria-hidden="true">
      <div className="art-header">
        <span className="art-tag">Live ranking · client.com</span>
        <span className="art-pill">+47 POS</span>
      </div>
      <div className="hero-chart">
        <HeroChart />
        <div className="chart-label" style={{ top: "6%", left: "4%" }}>Day 1 · #78</div>
        <div className="chart-label gold" style={{ bottom: "10%", right: "4%" }}>Day 90 · #3</div>
      </div>
      <div className="art-footer">
        <div className="art-stat"><div className="v">+312%</div><div className="l">Organic visits</div></div>
        <div className="art-stat"><div className="v">$4.2k</div><div className="l">Mo. revenue</div></div>
        <div className="art-stat"><div className="v">90d</div><div className="l">To Page 1</div></div>
      </div>
    </div>
  );
}

// ───────── Hero ─────────
function Hero({ variant, onCTA }) {
  const v = window.HERO_VARIANTS[variant] || window.HERO_VARIANTS["rank-reap"];

  return (
    <section className="hero container" id="top" data-screen-label="01 Hero">
      <div className="hero-grid">
        <div>
          <span className="badge-soft" style={{ marginBottom: 24, display: "inline-flex" }}>
            <span className="dot"></span> {v.eyebrow}
          </span>
          <h1 data-comment-anchor="hero-headline">
            <span className="ink2">{v.headline[0]}</span>{" "}
            <span className="serif" style={{ color: "var(--gold-deep)" }}>{v.headline[1]}</span>{" "}
            <span>{v.headline[2]}</span>
          </h1>
          <p className="hero-sub">{v.sub}</p>
          <div className="hero-ctas">
            <button className="btn btn-gold btn-lg" onClick={() => onCTA("buy")}>
              {v.primary} <span aria-hidden>→</span>
            </button>
            <button className="btn btn-ghost btn-lg" onClick={() => onCTA("preview")}>
              ▶ {v.secondary}
            </button>
            <a className="btn btn-text" href="#curriculum">See full curriculum</a>
          </div>
          <div className="hero-meta">
            <span className="stars">★★★★★</span>
            <span><strong style={{ color: "var(--ink)" }}>4.9</strong> from 2,148 reviews</span>
            <span className="dot"></span>
            <span><strong style={{ color: "var(--ink)" }}>4,200+</strong> operators trained</span>
            <span className="dot"></span>
            <span>60-day money-back</span>
          </div>
        </div>
        <HeroArt />
      </div>
    </section>
  );
}

// ───────── Logos band ─────────
function LogosBand() {
  const logos = [
    { name: "AHREFLY", sub: "Tooling partner" },
    { name: "Indie Hackers", sub: "Featured course" },
    { name: "Growth Weekly", sub: "Newsletter sponsor" },
    { name: "SERP Quarterly", sub: "Cover, Q2'26" },
    { name: "ProductHunt", sub: "#1 Product of the Day" },
  ];
  return (
    <div className="logos-band">
      <div className="container">
        <div className="logos-row">
          <span className="l-label">As seen in / partnered with</span>
          {logos.map((l) => (
            <span className="logo-item" key={l.name}>
              {l.name} <small>{l.sub}</small>
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ───────── Stat bar ─────────
function StatBar() {
  const stats = [
    { v: "4,200", suffix: "+", l: "Students trained" },
    { v: "47", suffix: "%", l: "Avg rank improvement" },
    { v: "4.9", suffix: "/5", l: "Rating, 2,148 reviews" },
    { v: "60", suffix: "d", l: "Money-back guarantee" },
  ];
  return (
    <section className="container" style={{ padding: "0 32px", margin: "0 auto" }}>
      <div className="stat-bar" data-screen-label="02 Stats">
        {stats.map((s, i) => (
          <div className="stat-cell" key={i}>
            <div className="v">{s.v}<span className="small">{s.suffix}</span></div>
            <div className="l">{s.l}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

// ───────── Modules ─────────
function ModulesSection({ onCTA }) {
  const [active, setActive] = useState(0);
  const mods = window.MODULES;
  const m = mods[active];

  return (
    <section className="section" id="curriculum" data-screen-label="03 Curriculum">
      <div className="container">
        <div className="section-head">
          <div>
            <span className="eyebrow">The curriculum</span>
            <h2 style={{ marginTop: 16 }}>Six modules.<br /><span className="serif" style={{ color: "var(--gold-deep)" }}>One ranking system.</span></h2>
          </div>
          <p>Built for beginners but respected by pros. Each module is 1–2 weeks, ends in a hands-on project, and unlocks the next as you finish. Click any module to peek inside.</p>
        </div>

        <div className="modules">
          <div className="module-tabs" role="tablist" aria-label="Course modules">
            {mods.map((mod, i) => (
              <button
                key={i}
                className="module-tab"
                role="tab"
                aria-selected={active === i}
                onClick={() => setActive(i)}
              >
                <span className="m-num">{mod.num}</span>
                <span className="m-title">{mod.title}</span>
              </button>
            ))}
          </div>

          <div className="module-panel" role="tabpanel">
            <div>
              <span className="m-eyebrow">{m.num} · {m.eyebrow}</span>
              <h3>{m.title}</h3>
              <p className="m-desc">{m.desc}</p>
              <div className="m-meta">
                <span><strong>{m.lessons}</strong></span>
                <span><strong>{m.weeks}</strong></span>
                <span>Project: <strong>{m.project}</strong></span>
              </div>
              <div style={{ marginTop: 28, display: "flex", gap: 10, flexWrap: "wrap" }}>
                <button className="btn btn-primary" onClick={() => onCTA("buy")}>Enroll for $497</button>
                <button className="btn btn-text" onClick={() => onCTA("preview")}>Watch a sample lesson →</button>
              </div>
            </div>

            <ul className="lesson-list">
              {m.items.map((it, i) => (
                <li key={i}>
                  <span className="l-num">{String(i + 1).padStart(2, "0")}</span>
                  <span className="l-name">{it.name}</span>
                  <span className="l-time">{it.time}</span>
                  {it.preview ? (
                    <button className="l-preview" onClick={() => onCTA("preview")}>Preview</button>
                  ) : (
                    <span className="l-time">🔒</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

// ───────── Offer ─────────
function Offer({ onCTA, showUrgency }) {
  const [time, setTime] = useState({ d: 3, h: 14, m: 22, s: 9 });

  useEffect(() => {
    const id = setInterval(() => {
      setTime((t) => {
        let { d, h, m, s } = t;
        s -= 1;
        if (s < 0) { s = 59; m -= 1; }
        if (m < 0) { m = 59; h -= 1; }
        if (h < 0) { h = 23; d -= 1; }
        if (d < 0) { d = 0; h = 0; m = 0; s = 0; }
        return { d, h, m, s };
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="section" id="pricing" data-screen-label="04 Pricing">
      <div className="container">
        <div className="offer">
          <div className="offer-left">
            <span className="eyebrow" style={{ color: "var(--gold)" }}>The full bundle</span>
            <h2 style={{ marginTop: 16 }}>Everything you need to grow a site in <span className="serif" style={{ color: "var(--gold)" }}>90 days.</span></h2>
            <p className="o-sub">A complete, opinionated system — not 47 hours of meandering lectures. We optimize for finished projects, not watched videos.</p>
            <ul className="bullets">
              <li>8-week curriculum across 6 modules · 53 lessons total</li>
              <li>Six hands-on projects with live workshop reviews</li>
              <li>Private community of 4,200+ operators (Discord)</li>
              <li>Templates: outlines, briefs, outreach scripts, SOPs</li>
              <li>Lifetime updates — yes, even when Google launches new things</li>
              <li>60-day, no-questions-asked refund</li>
            </ul>
          </div>
          <div className="offer-right">
            <div>
              <div className="price-strike">$697</div>
              <div className="price-now">
                <span className="currency">$</span>497
                <span className="term">one-time · lifetime access</span>
              </div>
              <div className="price-note" style={{ marginTop: 10 }}>or 3× $169 · 0% interest</div>
            </div>

            {showUrgency && (
              <div>
                <div className="price-note" style={{ marginBottom: 8 }}>Early-bird $200 off ends in</div>
                <div className="countdown">
                  <span className="v">{String(time.d).padStart(2, "0")}</span>d
                  <span className="v">{String(time.h).padStart(2, "0")}</span>h
                  <span className="v">{String(time.m).padStart(2, "0")}</span>m
                  <span className="v">{String(time.s).padStart(2, "0")}</span>s
                </div>
              </div>
            )}

            <div className="o-cta">
              <button className="btn btn-primary btn-lg" onClick={() => onCTA("buy")}>Get the bundle →</button>
              <button className="btn btn-ghost" style={{ borderColor: "var(--ink)", color: "var(--ink)" }} onClick={() => onCTA("preview")}>Free lesson first</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ───────── Testimonials ─────────
function TestimonialsSection() {
  return (
    <section className="section" id="results" data-screen-label="05 Results">
      <div className="container">
        <div className="section-head">
          <div>
            <span className="eyebrow">Receipts</span>
            <h2 style={{ marginTop: 16 }}>Real operators.<br /><span className="serif" style={{ color: "var(--gold-deep)" }}>Real revenue.</span></h2>
          </div>
          <p>We collect screenshots, not vanity quotes. Every testimonial below comes with a verifiable result — traffic, revenue, or rank position.</p>
        </div>

        <div className="testimonials">
          {window.TESTIMONIALS.map((t, i) => (
            <div className="testimonial" key={i}>
              <span className="t-stars">★★★★★</span>
              <p className="t-quote">"{t.quote}"</p>
              <div className="t-result">→ <strong>{t.result}</strong></div>
              <div className="t-author">
                <div className="t-avatar">{t.initials}</div>
                <div className="t-meta">
                  <div className="n">{t.name}</div>
                  <div className="r">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ───────── Blog cover art (abstract) ─────────
function PostCover({ idx }) {
  const variants = [
    // Wheat / rising bars
    <svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="250" fill="var(--bg-2)" />
      {Array.from({ length: 16 }).map((_, i) => {
        const x = 30 + i * 22;
        const h = 30 + i * 11;
        return <rect key={i} x={x} y={250 - h} width="10" height={h} fill={i % 3 === 0 ? "var(--gold)" : "var(--ink-2)"} opacity={0.6 + i * 0.025} />;
      })}
      <circle cx="340" cy="60" r="34" fill="var(--gold)" opacity="0.85" />
    </svg>,
    // Concentric grid
    <svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="250" fill="var(--bg-2)" />
      {Array.from({ length: 9 }).map((_, i) => (
        <rect key={i} x={20 + i * 8} y={20 + i * 8} width={360 - i * 16} height={210 - i * 16} fill="none" stroke="var(--ink-2)" strokeOpacity={0.4 - i * 0.04} />
      ))}
      <rect x="160" y="100" width="80" height="50" fill="var(--gold)" />
    </svg>,
    // Dotted matrix
    <svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="250" fill="var(--bg-2)" />
      {Array.from({ length: 12 }).map((_, r) =>
        Array.from({ length: 20 }).map((_, c) => {
          const cx = 20 + c * 20;
          const cy = 20 + r * 18;
          const isGold = (r + c) % 7 === 0;
          const isInk = (r * c) % 11 === 0;
          return <circle key={`${r}-${c}`} cx={cx} cy={cy} r={isGold ? 5 : 2.5} fill={isGold ? "var(--gold)" : isInk ? "var(--ink-2)" : "var(--mid)"} opacity={isGold ? 1 : 0.4} />;
        })
      )}
    </svg>,
    // Diagonal stripes with sun
    <svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="250" fill="var(--gold)" />
      <g transform="translate(0, 80)">
        {Array.from({ length: 8 }).map((_, i) => (
          <rect key={i} x="0" y={i * 22} width="400" height="10" fill="var(--ink-2)" opacity={0.85 - i * 0.08} />
        ))}
      </g>
      <circle cx="80" cy="60" r="40" fill="var(--bg)" />
    </svg>,
    // Tilted blocks
    <svg viewBox="0 0 400 250" preserveAspectRatio="xMidYMid slice">
      <rect width="400" height="250" fill="var(--ink-2)" />
      <rect x="40" y="60" width="120" height="130" fill="var(--gold)" transform="rotate(-8 100 125)" />
      <rect x="170" y="40" width="120" height="170" fill="var(--bg)" transform="rotate(6 230 125)" opacity="0.9" />
      <rect x="280" y="100" width="100" height="100" fill="var(--gold)" opacity="0.5" />
    </svg>,
  ];
  return variants[idx % variants.length];
}

// ───────── Blog / education ─────────
function BlogSection({ onCTA }) {
  return (
    <section className="section" id="blog" data-screen-label="06 Field Notes">
      <div className="container">
        <div className="section-head">
          <div>
            <span className="eyebrow">Field notes · weekly</span>
            <h2 style={{ marginTop: 16 }}>Free playbooks from <span className="serif" style={{ color: "var(--gold-deep)" }}>operators who ship.</span></h2>
          </div>
          <p>Tactics, case studies, and behind-the-scenes from sites we're actively running. No fluff, no SEO Twitter takes. Subscribe for one email every Tuesday.</p>
        </div>

        <div className="blog-grid">
          {/* Featured */}
          <article className="post featured">
            <div className="post-cover"><PostCover idx={window.POSTS[0].art} /></div>
            <div className="post-body">
              <span className="post-cat">{window.POSTS[0].cat}</span>
              <h3 className="post-title">{window.POSTS[0].title}</h3>
              <p className="post-excerpt">{window.POSTS[0].excerpt}</p>
              <div className="post-meta">
                <span>{window.POSTS[0].date} · {window.POSTS[0].read}</span>
                <a className="post-cta-inline" href="#">Read the breakdown →</a>
              </div>
            </div>
          </article>

          {/* Inline ad — alongside featured */}
          <div className="ad-slot">
            <span className="ad-label">Sponsored</span>
            <span className="ad-eye">Tool partner</span>
            <h3 className="ad-headline">Find under-priced keywords in 60 seconds.</h3>
            <p className="ad-body">Our partner tool ships a free trial for SEO Harvest readers. We use it daily.</p>
            <button className="btn btn-gold" style={{ alignSelf: "flex-start", marginTop: 12 }} onClick={() => onCTA("buy")}>Try it free →</button>
          </div>

          {/* Standard posts */}
          {window.POSTS.slice(1, 3).map((p, i) => (
            <article className="post" key={i}>
              <div className="post-cover"><PostCover idx={p.art} /></div>
              <div className="post-body">
                <span className="post-cat">{p.cat}</span>
                <h3 className="post-title">{p.title}</h3>
                <p className="post-excerpt">{p.excerpt}</p>
                <div className="post-meta">
                  <span>{p.date} · {p.read}</span>
                  <a className="post-cta-inline" href="#">Read →</a>
                </div>
              </div>
            </article>
          ))}

          {/* Wide ad/CTA in the middle of the grid */}
          <div className="ad-slot wide">
            <span className="ad-label">In-house</span>
            <h3 className="ad-headline">New: the 5-day SEO starter — free, no card.</h3>
            <button className="btn btn-primary" onClick={() => onCTA("preview")}>Send me lesson 1 →</button>
          </div>

          {/* More posts */}
          {window.POSTS.slice(3).map((p, i) => (
            <article className="post" key={i}>
              <div className="post-cover"><PostCover idx={p.art} /></div>
              <div className="post-body">
                <span className="post-cat">{p.cat}</span>
                <h3 className="post-title">{p.title}</h3>
                <p className="post-excerpt">{p.excerpt}</p>
                <div className="post-meta">
                  <span>{p.date} · {p.read}</span>
                  <a className="post-cta-inline" href="#">Read →</a>
                </div>
              </div>
            </article>
          ))}

          {/* Third inline ad — affiliate */}
          <div className="ad-slot">
            <span className="ad-label">Affiliate</span>
            <span className="ad-eye">Recommended hosting</span>
            <h3 className="ad-headline">The host we run all our SEO sites on.</h3>
            <p className="ad-body">$3/mo for the first year, free CDN, free SSL. Use code HARVEST for an extra 10%.</p>
            <a className="btn btn-ghost" style={{ alignSelf: "flex-start", marginTop: 12 }} href="#">Read review →</a>
          </div>
        </div>

        <div style={{ marginTop: 40, display: "flex", justifyContent: "center" }}>
          <a className="btn btn-ghost btn-lg" href="#">Browse all 142 articles →</a>
        </div>
      </div>
    </section>
  );
}

// ───────── Footer ─────────
function Footer({ onCTA }) {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-top">
          <div className="footer-brand">
            <div className="logo" style={{ color: "var(--bg)" }}>
              <span className="logo-mark" style={{ color: "var(--gold)" }}><LogoMark /></span>
              The SEO Harvest
            </div>
            <p>An honest SEO bootcamp for total beginners. Built by operators who still run sites — not gurus selling courses about selling courses.</p>
            <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
              <button className="btn btn-gold" onClick={() => onCTA("buy")}>Enroll — $497</button>
              <button className="btn btn-ghost" style={{ borderColor: "rgba(255,255,255,0.2)", color: "var(--bg)" }} onClick={() => onCTA("preview")}>Free lesson</button>
            </div>
          </div>
          <div>
            <h4>Course</h4>
            <a href="#curriculum">Curriculum</a>
            <a href="#pricing">Pricing</a>
            <a href="#">For teams</a>
            <a href="#">Gift a seat</a>
          </div>
          <div>
            <h4>Resources</h4>
            <a href="#blog">Field notes</a>
            <a href="#">Free templates</a>
            <a href="#">Affiliate program</a>
            <a href="#">SEO glossary</a>
          </div>
          <div>
            <h4>Company</h4>
            <a href="#">About</a>
            <a href="#">Reviews</a>
            <a href="#">Support</a>
            <a href="#">Privacy</a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 The SEO Harvest</span>
          <span>Made on a farm in Vermont · & on the internet</span>
        </div>
      </div>
    </footer>
  );
}

// ───────── Email-capture Modal ─────────
function EmailModal({ kind, onClose }) {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [err, setErr] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const emailRef = useRef(null);

  useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    setTimeout(() => emailRef.current?.focus(), 100);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const validate = (e) => {
    e.preventDefault();
    if (!name.trim()) { setErr("Please enter your first name."); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setErr("That email doesn't look right."); return; }
    setErr("");
    setSubmitted(true);
  };

  const isBuy = kind === "buy";

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close" onClick={onClose} aria-label="Close">×</button>

        <div className="modal-main">
          {submitted ? (
            <div>
              <span className="eyebrow" style={{ color: "var(--leaf)" }}>You're in</span>
              <h3 style={{ marginTop: 14 }}>Check <span className="serif" style={{ color: "var(--gold-deep)" }}>{email}</span></h3>
              <p className="m-sub">Lesson 1 is on its way. If it doesn't land in 2 minutes, peek in Promotions — we hate it there too.</p>
              <ul className="modal-bullets">
                <li>5 emails over 5 days · 8 min each</li>
                <li>One actual ranking experiment you can ship today</li>
                <li>No upsell until day 5, promise</li>
              </ul>
              <button className="btn btn-primary" style={{ marginTop: 24 }} onClick={onClose}>Back to the page</button>
            </div>
          ) : (
            <form onSubmit={validate}>
              <span className="eyebrow">
                {isBuy ? "Reserve your seat" : "Free 5-day SEO starter"}
              </span>
              <h3 style={{ marginTop: 14 }}>
                {isBuy ? (
                  <>Hold a seat in <span className="serif" style={{ color: "var(--gold-deep)" }}>Cohort 12.</span></>
                ) : (
                  <>Get lesson 1 in <span className="serif" style={{ color: "var(--gold-deep)" }}>under a minute.</span></>
                )}
              </h3>
              <p className="m-sub">
                {isBuy
                  ? "We'll email you the enrollment link plus a payment-plan option. No charge until you finish checkout."
                  : "A 5-day email crash course. Real tactics, no fluff, unsubscribe with one click."}
              </p>

              <div className="modal-form">
                <div>
                  <label htmlFor="m-name">First name</label>
                  <input
                    id="m-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Alex"
                    className={err && !name.trim() ? "err" : ""}
                  />
                </div>
                <div>
                  <label htmlFor="m-email">Email</label>
                  <input
                    id="m-email"
                    ref={emailRef}
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@gmail.com"
                    className={err && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "err" : ""}
                  />
                </div>
                {err && <div className="form-err">{err}</div>}
                <button className="btn btn-primary btn-lg" type="submit" style={{ marginTop: 6 }}>
                  {isBuy ? "Reserve my seat →" : "Send me lesson 1 →"}
                </button>
                <p style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--mid)", textTransform: "uppercase", letterSpacing: "0.08em", marginTop: 4 }}>
                  No spam · unsubscribe anytime · we read every reply
                </p>
              </div>
            </form>
          )}
        </div>

        <div className="modal-side">
          <div>
            <span className="ms-eye">What you'll get</span>
            <div className="ms-h">
              From <em>zero</em><br />to your first<br />Page-1 rank.
            </div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div className="ms-stat">★★★★★ <strong>4.9 / 5</strong> across 2,148 reviews</div>
            <div className="ms-stat"><strong>4,200+</strong> beginners enrolled</div>
            <div className="ms-stat"><strong>60-day</strong> money-back · no questions</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ───────── Sticky bar ─────────
function StickyBar({ onCTA }) {
  return (
    <div className="stickybar">
      <span className="sb-strike">$697</span>
      <span className="sb-price">$497</span>
      <span style={{ opacity: 0.7 }}>· lifetime · cohort 12 fills July 8</span>
      <button className="btn btn-gold" onClick={() => onCTA("buy")}>Enroll →</button>
    </div>
  );
}

Object.assign(window, {
  LogoMark,
  TopBar,
  UrgencyStrip,
  Hero,
  LogosBand,
  StatBar,
  ModulesSection,
  Offer,
  TestimonialsSection,
  BlogSection,
  Footer,
  EmailModal,
  StickyBar,
});
