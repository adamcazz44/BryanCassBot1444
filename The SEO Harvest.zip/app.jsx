// Main app for The SEO Harvest

const { useState, useEffect } = React;

const PALETTES = [
  { key: "harvest", label: "Harvest", colors: ["#f4ede0", "#c4934a", "#3d2f1f"] },
  { key: "paper", label: "Paper", colors: ["#fafaf6", "#d97706", "#111111"] },
  { key: "midnight", label: "Midnight", colors: ["#0f140d", "#d4b85a", "#a8c47a"] },
  { key: "ember", label: "Ember", colors: ["#f6ede1", "#e85d2f", "#2a160a"] },
];

// Inline swatch picker — TweakColor compares JSON-stringified options, which
// makes name-keyed palettes awkward. Roll a tiny custom control instead so we
// keep simple string keys and get the swatch UI we want.
function PaletteSwatch({ value, onChange }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 8, marginBottom: 14 }}>
      {PALETTES.map((p) => {
        const on = p.key === value;
        return (
          <button
            key={p.key}
            type="button"
            onClick={() => onChange(p.key)}
            aria-pressed={on}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 10px",
              borderRadius: 10,
              border: on ? "1.5px solid #111" : "1px solid rgba(0,0,0,0.12)",
              background: on ? "rgba(0,0,0,0.04)" : "#fff",
              cursor: "pointer",
              fontFamily: "system-ui, sans-serif",
              fontSize: 12,
              fontWeight: 500,
              color: "#111",
              textAlign: "left",
            }}
          >
            <span style={{ display: "inline-flex", borderRadius: 6, overflow: "hidden", border: "1px solid rgba(0,0,0,0.1)" }}>
              {p.colors.map((c, i) => (
                <span key={i} style={{ width: 14, height: 18, background: c, display: "block" }}></span>
              ))}
            </span>
            {p.label}
          </button>
        );
      })}
    </div>
  );
}

function App() {
  const [tweaks, setTweak] = window.useTweaks(window.__TWEAK_DEFAULTS);
  const [modal, setModal] = useState(null); // null | "buy" | "preview"

  useEffect(() => {
    document.body.dataset.palette = tweaks.palette;
  }, [tweaks.palette]);

  const onCTA = (kind) => setModal(kind);
  const closeModal = () => setModal(null);

  return (
    <>
      {tweaks.showUrgency && <window.UrgencyStrip />}
      <window.TopBar onCTA={onCTA} />
      <window.Hero variant={tweaks.heroVariant} onCTA={onCTA} />
      <window.LogosBand />
      <div style={{ height: 80 }}></div>
      <window.StatBar />
      <window.ModulesSection onCTA={onCTA} />
      <window.TestimonialsSection />
      <window.Offer onCTA={onCTA} showUrgency={tweaks.showUrgency} />
      <window.BlogSection onCTA={onCTA} />
      <window.Footer onCTA={onCTA} />

      {modal && <window.EmailModal kind={modal} onClose={closeModal} />}
      {tweaks.showStickyBar && !modal && <window.StickyBar onCTA={onCTA} />}

      <window.TweaksPanel title="Tweaks">
        <window.TweakSection label="Palette">
          <PaletteSwatch value={tweaks.palette} onChange={(v) => setTweak("palette", v)} />
        </window.TweakSection>

        <window.TweakSection label="Hero">
          <window.TweakSelect
            label="Headline"
            value={tweaks.heroVariant}
            onChange={(v) => setTweak("heroVariant", v)}
            options={[
              { value: "rank-reap", label: "Rank. Reap. Repeat." },
              { value: "page-one", label: "Zero to Page 1" },
              { value: "plant-rank", label: "Plant rankings." },
            ]}
          />
        </window.TweakSection>

        <window.TweakSection label="Conversion">
          <window.TweakToggle
            label="Urgency strip + countdown"
            value={tweaks.showUrgency}
            onChange={(v) => setTweak("showUrgency", v)}
          />
          <window.TweakToggle
            label="Sticky-bottom buy bar"
            value={tweaks.showStickyBar}
            onChange={(v) => setTweak("showStickyBar", v)}
          />
        </window.TweakSection>
      </window.TweaksPanel>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
